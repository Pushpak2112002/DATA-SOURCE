import React from 'react';
import Transactions from './Transactions';

const App = () => {
  return (
    <div className="App">
      <Transactions />
    </div>
  );
};

export default App;
