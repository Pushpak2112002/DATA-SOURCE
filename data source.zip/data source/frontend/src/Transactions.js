import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import './Transactions.css';

// Register the required components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const Transactions = () => {
  const [transactions, setTransactions] = useState([]);
  const [month, setMonth] = useState('January'); // Default month to January
  const [searchTerm, setSearchTerm] = useState('');
  const [totalPages, setTotalPages] = useState(0);

  const months = [
    'January', 'February', 'March', 'April', 'May',
    'June', 'July', 'August', 'September', 'October',
    'November', 'December'
  ];

  useEffect(() => {
    fetchTransactions();
  }, [month, searchTerm]);

  const fetchTransactions = async () => {
    try {
      // Use the appropriate endpoint based on your requirements
      const response = await axios.get('http://localhost:5000/api/price-range-statistics', {
        params: { month },
      });
      // Assuming response.data is an array of transaction data
      setTransactions(response.data);
      // Optionally handle total pages if needed for pagination (if API provides this info)
      // setTotalPages(Math.ceil(response.data.total / 10)); // Adjust if you receive pagination data
    } catch (error) {
      console.error('Error fetching transactions:', error);
    }
  };

  const handleMonthChange = (e) => {
    setMonth(e.target.value);
  };

  const chartData = {
    labels: transactions.map((tx) => tx.productTitle), // Adjust based on your data structure
    datasets: [
      {
        label: 'Transaction Prices',
        data: transactions.map((tx) => tx.price), // Adjust based on your data structure
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
    ],
  };

  return (
    <div className="transactions-container">
      <h1>Transactions</h1>
      <div className="controls">
        <select value={month} onChange={handleMonthChange}>
          {months.map((m, index) => (
            <option key={index} value={m}>{m}</option>
          ))}
        </select>
        <input
          type="text"
          placeholder="Search transactions..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      <table className="transactions-table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Price</th>
            <th>Date of Sale</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((transaction, index) => (
            <tr key={index}>
              <td>{transaction.productTitle}</td>
              <td>{transaction.productDescription}</td>
              <td>${transaction.price}</td>
              <td>{new Date(transaction.dateOfSale).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="chart-container">
        <h2>Transaction Prices Chart</h2>
        <Bar data={chartData} />
      </div>
    </div>
  );
};

export default Transactions;
